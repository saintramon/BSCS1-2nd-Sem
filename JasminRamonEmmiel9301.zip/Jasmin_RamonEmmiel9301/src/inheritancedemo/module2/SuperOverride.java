package inheritancedemo.module2;

public class SuperOverride {
    public void methodOne() {
        System.out.println("methodOne from superclass...");
    }
    protected void methodTwo() {
        System.out.println("methodTwo from superclass...");
    }
    public void methodThree() {
        System.out.println("methodThree from superclass...");
    }
}
